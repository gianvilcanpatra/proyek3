<?php

namespace App\Http\Controllers;

use App\Models\pengguna;
use Illuminate\Http\Request;

class PenggunaController extends Controller
{
    public function index(){
         $data = pengguna::all();
        return view('datapengguna', compact('data'));   
    }
}
